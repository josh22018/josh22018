<p align="center">
  <img src="./cards/hero.svg" width="100%" alt="Joshith Gadi, AI engineer" />
</p>

<p align="center">
  <img src="./cards/graph.svg" width="100%" alt="Contribution graph" />
</p>

<p align="center">
  <img src="./cards/activity.svg" width="100%" alt="Monthly contributions and streak stats" />
</p>

<p align="center">
  <a href="https://github.com/josh22018?tab=repositories"><img src="./cards/build.svg" width="32.5%" alt="Build" /></a>
  <a href="https://www.researchgate.net/scientific-contributions/Gadi-Joshith-2296715092"><img src="./cards/research.svg" width="32.5%" alt="Research" /></a>
  <a href="https://github.com/josh22018?tab=stars"><img src="./cards/learn.svg" width="32.5%" alt="Learn" /></a>
</p>

<p align="center">
  <a href="https://github.com/josh22018/ai-powered-trading-system"><img src="./cards/repo-1.svg" width="49.5%" alt="ai-powered-trading-system" /></a>
  <a href="https://github.com/josh22018/inventory-demand"><img src="./cards/repo-2.svg" width="49.5%" alt="inventory-demand" /></a>
</p>

<p align="center">
  <a href="https://github.com/josh22018/Dermify-Intelligent-Skin-Disesase-Detection-Web-Application"><img src="./cards/repo-3.svg" width="49.5%" alt="dermify" /></a>
  <a href="https://github.com/josh22018/QSecure-Secure-File-Encryption-Decryption-System-using-Quantum-Cryptography"><img src="./cards/repo-4.svg" width="49.5%" alt="qsecure" /></a>
</p>
